﻿using System;
using System.Windows;
using Excel = Microsoft.Office.Interop.Excel;
using ExcelSpreadsheets.Model;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using System.Threading;

namespace ExcelSpreadsheets
{
    public partial class MainWindow : Window
    {
        Excel.Application xlApp;

        public ObservableCollection<MyClass> MyData { get; set; }
        Random rand = new Random(DateTime.Now.Second);

        public MainWindow()
        {
            InitializeComponent();
            LoadData();
            DataContext = this;

            Task.Factory.StartNew(() => { StartProcessing(); });
        }

        private void StartProcessing()
        {
            foreach (var job in MyData)
            {
                job.JobStatus = JobStatuses.Working;
                Thread.Sleep(1000);
                job.JobStatus = (rand.Next(2) > 0) ? JobStatuses.Pass : JobStatuses.Fail;

            }
        }

        private void LoadData()
        {
            MyData = new ObservableCollection<MyClass>();

            Excel.Workbook xlWorkBook;
            Excel.Worksheet xlWorkSheet;
            Excel.Range range;

            xlApp = new Excel.Application();
            var path = System.IO.Path.Combine(System.AppDomain.CurrentDomain.BaseDirectory, "Model", "Book1.xls");
            xlWorkBook = xlApp.Workbooks.Open(path, 0, true, 5, "", "", true, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "\t", false, false, 0, true, 1, 0);
            xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);

            range = xlWorkSheet.UsedRange;

            for (var rCnt = 2; rCnt <= range.Rows.Count; rCnt++)
            {
                    MyData.Add(new MyClass
                    {
                        UserID = (int)(range.Cells[rCnt, 1] as Excel.Range).Value2,
                        Name = (string)(range.Cells[rCnt, 2] as Excel.Range).Value2,
                        Type = (UserTypes)Enum.Parse(typeof(UserTypes),(string)(range.Cells[rCnt, 3] as Excel.Range).Value2)
                    });
            }

            xlWorkBook.Close(true, null, null);
            xlApp.Quit();

            releaseObject(xlWorkSheet);
            releaseObject(xlWorkBook);
            releaseObject(xlApp);
        }

        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Unable to release the Object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        } 

    }
}
