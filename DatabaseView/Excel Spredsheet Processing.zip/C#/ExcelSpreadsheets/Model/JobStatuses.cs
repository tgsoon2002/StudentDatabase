﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExcelSpreadsheets.Model
{
    public enum JobStatuses
    {
        Idle,
        Working,
        Pass,
        Fail
    }
}
