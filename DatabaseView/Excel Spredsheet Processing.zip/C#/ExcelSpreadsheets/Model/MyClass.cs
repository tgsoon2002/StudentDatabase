﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

namespace ExcelSpreadsheets.Model
{
    public class MyClass : INotifyPropertyChanged
    {
        int _UserID;
        public int UserID
        {
            get
            {
                return _UserID;
            }
            set
            {
                if (_UserID != value)
                {
                    _UserID = value;
                    RaisePropertyChanged("UserID");
                }
            }
        }

        string _Name;
        public string Name
        {
            get
            {
                return _Name;
            }
            set
            {
                if (_Name != value)
                {
                    _Name = value;
                    RaisePropertyChanged("Name");
                }
            }
        }

        UserTypes _Type;
        public UserTypes Type
        {
            get
            {
                return _Type;
            }
            set
            {
                if (_Type != value)
                {
                    _Type = value;
                    RaisePropertyChanged("Type");
                }
            }
        }

        JobStatuses _JobStatus;
        public JobStatuses JobStatus
        {
            get
            {
                return _JobStatus;
            }
            set
            {
                if (_JobStatus != value)
                {
                    _JobStatus = value;
                    RaisePropertyChanged("JobStatus");
                }
            }
        }


        void RaisePropertyChanged(string prop)
        {
            if (PropertyChanged != null) { PropertyChanged(this, new PropertyChangedEventArgs(prop)); }
        }
        public event PropertyChangedEventHandler PropertyChanged;

    }
}
